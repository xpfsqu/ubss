"""
ssp_mia.py — Reference implementation of SSP-MIA.

Underdetermined Blind Source Separation via Time–Frequency Single-Source
Point Detection and Minimum Intersection Angle Rule.

This module implements Algorithm 1 of the paper:
    1. STFT front end.
    2. Collinearity-based single-source point (SSP) detection with an
       energy floor (Eq. 5-6).
    3. Phase-invariant direction estimation via the Gram-matrix top
       eigenvector (Eq. 7-8).
    4. Source-number estimation by the gap statistic on projective data
       (Eq. 10).
    5. Mixing-matrix estimation by spherical k-means with antipodal
       distance (Eq. 9) and R random restarts.
    6. Source recovery: nearest-column rule at SSP bins (Eq. 11),
       generalised TF MIA at multi-active bins (Eq. 12-13), and a
       noise-aware complex l1 fall-back (Eq. 14).
    7. Inverse STFT with overlap-add.

Dependencies: numpy, scipy. The l1 fall-back optionally uses cvxpy (SCS);
if cvxpy is unavailable it falls back to a damped least-squares solve so
the pipeline still runs.

This file is part of the public reproduction package referenced in Section 5 (Reproducibility) of the paper.
"""

from __future__ import annotations
import numpy as np
from scipy.signal import stft, istft
from itertools import permutations

try:
    import cvxpy as cp
    _HAVE_CVXPY = True
except Exception:
    _HAVE_CVXPY = False


# ---------------------------------------------------------------------------
# 1. STFT helpers
# ---------------------------------------------------------------------------
def forward_stft(x, fs, nperseg=256, overlap=0.75):
    """Multichannel STFT. x is (m, T). Returns (f, t, X) with X (m, F, P)."""
    hop = int(nperseg * (1 - overlap))
    Xs = []
    for ch in range(x.shape[0]):
        f, t, Z = stft(x[ch], fs=fs, window="hann", nperseg=nperseg,
                       noverlap=nperseg - hop, boundary=None, padded=False)
        Xs.append(Z)
    X = np.stack(Xs, axis=0)            # (m, F, P)
    return f, t, X, hop


def inverse_stft(S, fs, nperseg=256, overlap=0.75):
    """Inverse STFT of S (n, F, P) -> (n, T)."""
    hop = int(nperseg * (1 - overlap))
    outs = []
    for src in range(S.shape[0]):
        _, xrec = istft(S[src], fs=fs, window="hann", nperseg=nperseg,
                        noverlap=nperseg - hop, boundary=None)
        outs.append(xrec)
    L = min(len(o) for o in outs)
    return np.stack([o[:L] for o in outs], axis=0)


# ---------------------------------------------------------------------------
# 2. SSP detection (Eq. 5-6)
# ---------------------------------------------------------------------------
def estimate_sigma_tf(X, eta, sigma0):
    """MAD-based STFT noise std over energy-floor failures (proxy noise set)."""
    Xr, Xi = X.real, X.imag
    nr = np.linalg.norm(Xr, axis=0)        # (F, P)
    ni = np.linalg.norm(Xi, axis=0)
    floor = np.minimum(nr, ni) < eta * sigma0
    mags = np.abs(X)[:, floor]
    if mags.size == 0:
        return sigma0
    med = np.median(mags)
    return 1.4826 * med


def detect_ssp(X, tau=0.99, eta=3.0, sigma_tf=None, eps=1e-12):
    """
    Return a boolean mask (F, P) of detected SSPs and the collinearity map.
    Implements Eq. (5) and the joint test Eq. (6).
    """
    Xr, Xi = X.real, X.imag                       # (m, F, P)
    dot = np.sum(Xr * Xi, axis=0)                 # (F, P)
    nr = np.linalg.norm(Xr, axis=0)
    ni = np.linalg.norm(Xi, axis=0)
    coll = np.abs(dot) / (nr * ni + eps)          # Eq. (5)
    if sigma_tf is None:
        sigma_tf = 1.0
    energy_ok = np.minimum(nr, ni) >= eta * sigma_tf
    mask = energy_ok & (coll >= tau)              # Eq. (6)
    return mask, coll


# ---------------------------------------------------------------------------
# 3. Gram-matrix direction estimate (Eq. 7-8)
# ---------------------------------------------------------------------------
def gram_directions(X, mask):
    """
    For each SSP bin, return the unit top eigenvector of the Gram matrix
    G = Re Re^T + Im Im^T (Eq. 7), flipped to the upper hemisphere.
    Returns U of shape (K, m).
    """
    m = X.shape[0]
    idx = np.argwhere(mask)                       # (K, 2): (f, p)
    U = np.zeros((len(idx), m))
    for k, (fi, pi) in enumerate(idx):
        xr = X[:, fi, pi].real
        xi = X[:, fi, pi].imag
        G = np.outer(xr, xr) + np.outer(xi, xi)   # (m, m), Eq. (7)
        w, V = np.linalg.eigh(G)                   # ascending
        u = V[:, -1]                               # top eigenvector, Eq. (8)
        if u[-1] < 0:                              # hemisphere flip
            u = -u
        U[k] = u
    return U, idx


# ---------------------------------------------------------------------------
# 4. Spherical k-means with antipodal distance (Eq. 9)
# ---------------------------------------------------------------------------
def _antipodal_assign(U, C):
    """Assign each row of U to nearest centroid under d=1-|u.v| (Eq. 9)."""
    sim = np.abs(U @ C.T)                          # (K, k)
    return np.argmax(sim, axis=1)


def spherical_kmeans(U, k, n_restarts=10, max_iter=100, tol=1e-6, rng=None):
    """Spherical k-means on the projective sphere (antipodal distance)."""
    rng = np.random.default_rng() if rng is None else rng
    best_W, best_C, best_lab = np.inf, None, None
    K = len(U)
    for _ in range(n_restarts):
        # k-means++ style seeding on antipodal distance
        c0 = rng.integers(K)
        centroids = [U[c0]]
        for _ in range(1, k):
            d = 1 - np.max(np.abs(U @ np.array(centroids).T), axis=1)
            p = np.maximum(d, 0.0)
            s = p.sum()
            # robust normalisation: fall back to uniform if all-zero, and
            # renormalise so the vector sums to 1 within numpy's tolerance.
            p = np.full(K, 1.0 / K) if s <= 0 else p / s
            p = p / p.sum()
            centroids.append(U[rng.choice(K, p=p)])
        C = np.array(centroids)
        prevW = np.inf
        for _ in range(max_iter):
            lab = _antipodal_assign(U, C)
            newC = np.zeros_like(C)
            for r in range(k):
                pts = U[lab == r]
                if len(pts) == 0:
                    newC[r] = U[rng.integers(K)]
                    continue
                # principal axis of the cluster (handles antipodal sign)
                G = pts.T @ pts
                w, V = np.linalg.eigh(G)
                newC[r] = V[:, -1]
            W = np.sum(1 - np.max(np.abs(U @ newC.T), axis=1))
            C = newC
            if np.isfinite(prevW) and abs(prevW - W) / (prevW + 1e-12) < tol:
                break
            prevW = W
        if W < best_W:
            best_W, best_C, best_lab = W, C.copy(), lab.copy()
    return best_C, best_lab, best_W


# ---------------------------------------------------------------------------
# 5. Gap statistic for source number (Eq. 10)
# ---------------------------------------------------------------------------
def gap_statistic(U, k_max=8, B=20, rng=None):
    """Estimate the number of clusters on projective spherical data (Eq. 10)."""
    rng = np.random.default_rng() if rng is None else rng
    K, m = U.shape
    logW = np.zeros(k_max + 1)
    logWstar = np.zeros((k_max + 1, B))
    for k in range(1, k_max + 1):
        _, _, W = spherical_kmeans(U, k, n_restarts=3, rng=rng)
        logW[k] = np.log(W + 1e-12)
        for b in range(B):
            # uniform points on the upper hemisphere of S^{m-1}
            R = rng.normal(size=(K, m))
            R /= np.linalg.norm(R, axis=1, keepdims=True)
            R[R[:, -1] < 0] *= -1
            _, _, Wb = spherical_kmeans(R, k, n_restarts=1, rng=rng)
            logWstar[k, b] = np.log(Wb + 1e-12)
    gap = logWstar.mean(axis=1) - logW
    sk = logWstar.std(axis=1) * np.sqrt(1 + 1.0 / B)
    for k in range(1, k_max):
        if gap[k] >= gap[k + 1] - sk[k + 1]:
            return k
    return k_max


# ---------------------------------------------------------------------------
# 6. Source recovery (Eq. 11-14)
# ---------------------------------------------------------------------------
def _l1_complex(x, A, nu, use_cvxpy=False):
    """
    Complex l1 recovery (Eq. 14). By default uses a fast NumPy iterative
    reweighted least-squares (IRLS) surrogate for the l1 objective, which is
    orders of magnitude faster per call than spinning up a CVXPY/SCS problem
    and is accurate enough for the small fraction of bins that reach this
    fall-back. Set use_cvxpy=True to solve the exact SOCP with SCS.
    """
    m, n = A.shape
    if use_cvxpy and _HAVE_CVXPY:
        sr = cp.Variable(n); si = cp.Variable(n)
        resid_r = A @ sr - x.real
        resid_i = A @ si - x.imag
        cons = [cp.norm(cp.hstack([resid_r, resid_i]), 2) <= nu]
        obj = cp.Minimize(cp.sum(cp.norm(cp.vstack([sr, si]), axis=0)))
        prob = cp.Problem(obj, cons)
        try:
            prob.solve(solver=cp.SCS, eps=1e-4, max_iters=2500, verbose=False)
            if sr.value is not None:
                return sr.value + 1j * si.value
        except Exception:
            pass
    # Fast IRLS surrogate for min ||s||_1 s.t. ||As - x|| <= nu.
    # Solve the Lagrangian min ||As-x||^2 + lam ||s||_1 via reweighted ridge.
    lam = max(nu, 1e-6)
    s = np.linalg.lstsq(A, x, rcond=None)[0].astype(complex)
    for _ in range(8):
        w = 1.0 / (np.abs(s) + 1e-3)            # reweighting -> l1 surrogate
        W = np.diag(w)
        # (A^H A + lam W) s = A^H x
        AhA = A.conj().T @ A
        try:
            s = np.linalg.solve(AhA + lam * W, A.conj().T @ x)
        except np.linalg.LinAlgError:
            break
    return s


def recover_sources(X, A_hat, mask, U, idx, n, delta_deg=5.0, sigma_tf=1.0):
    """
    Recover S (n, F, P).

    For underdetermined TF-masking BSS the source estimate at a bin assigned
    to source i is taken from the *reference mixture channel* (the channel in
    which column i has the largest gain), masked to the bins assigned to i.
    This DUET-style reconstruction preserves the source waveform up to the
    per-source gain a_{c,i}, whereas the naive projection a_i^H x mixes in all
    other columns and destroys separation. We compensate the gain so the
    returned estimate is on the source scale.

    SSP bins: nearest-column assignment (Eq. 11). Non-SSP bins: generalised
    MIA assignment (Eq. 12-13) selecting the single best-aligned column for
    masking; the l1 fall-back (Eq. 14) is used at ambiguous bins to split
    energy across the m best columns.
    """
    m, F, P = X.shape
    S = np.zeros((n, F, P), dtype=complex)
    A_hat = A_hat / np.linalg.norm(A_hat, axis=0, keepdims=True)
    delta = np.deg2rad(delta_deg)
    nu = 2.0 * np.sqrt(m) * sigma_tf

    # reference channel per source: the row with largest |a_{c,i}|
    refch = np.argmax(np.abs(A_hat), axis=0)        # (n,)
    refgain = A_hat[refch, np.arange(n)]            # (n,)

    ssp_set = set(map(tuple, idx.tolist())) if len(idx) else set()
    Xn = np.linalg.norm(X, axis=0)

    for fi in range(F):
        for pi in range(P):
            xn = Xn[fi, pi]
            if xn < 1e-12:
                continue
            x = X[:, fi, pi]
            cosang = np.clip(np.abs(A_hat.T @ x) / (xn + 1e-12), 0, 1)
            theta = np.arccos(cosang)
            order = np.argsort(theta)

            is_ssp = (fi, pi) in ssp_set
            if is_ssp or n <= m or (theta[order[min(m, n-1)]]
                                    - theta[order[m-1]] >= delta):
                # confident single-source (or MIA-resolvable): hard-assign the
                # dominant column and reconstruct from its reference channel.
                i = int(order[0])
                c = refch[i]
                S[i, fi, pi] = X[c, fi, pi] / refgain[i]
            else:
                # ambiguous multi-active bin: l1 split across columns (Eq. 14)
                s = _l1_complex(x, A_hat, nu)
                S[:, fi, pi] = s
    return S


# ---------------------------------------------------------------------------
# 7. Top-level driver
# ---------------------------------------------------------------------------
def ssp_mia(x, fs, n=None, nperseg=256, overlap=0.75,
            tau=0.99, eta=3.0, sigma0=None, delta_deg=5.0,
            n_restarts=10, k_max=8, rng=None):
    """
    Full SSP-MIA pipeline. x is (m, T).
    Returns dict with estimated mixing matrix A_hat, sources s_hat (n, T),
    SSP mask, and the estimated source count n_hat.
    """
    rng = np.random.default_rng() if rng is None else rng
    f, t, X, hop = forward_stft(x, fs, nperseg, overlap)

    if sigma0 is None:
        # rough noise scale from the lowest-energy 10% of bins
        e = np.linalg.norm(X, axis=0).ravel()
        sigma0 = np.percentile(e, 10) / max(np.sqrt(X.shape[0]), 1)
    sigma_tf = estimate_sigma_tf(X, eta, sigma0)

    mask, coll = detect_ssp(X, tau=tau, eta=eta, sigma_tf=sigma_tf)
    U, idx = gram_directions(X, mask)
    if len(U) < (n or 2):
        raise RuntimeError("Too few SSPs detected; lower tau or eta.")

    n_hat = n if n is not None else gap_statistic(U, k_max=k_max, rng=rng)
    C, lab, _ = spherical_kmeans(U, n_hat, n_restarts=n_restarts, rng=rng)
    A_hat = C.T                                   # (m, n_hat)

    S = recover_sources(X, A_hat, mask, U, idx, n_hat,
                        delta_deg=delta_deg, sigma_tf=sigma_tf)
    s_hat = inverse_stft(S, fs, nperseg, overlap)
    return dict(A_hat=A_hat, s_hat=s_hat, ssp_mask=mask,
                n_hat=n_hat, sigma_tf=sigma_tf, ssp_count=len(U))


# ---------------------------------------------------------------------------
# 8. Evaluation helpers
# ---------------------------------------------------------------------------
def matrix_error(A_hat, A_true):
    """E_A = min over permutation/sign of ||A_hat P D - A||_F / ||A||_F."""
    A_hat = A_hat / np.linalg.norm(A_hat, axis=0, keepdims=True)
    A_true = A_true / np.linalg.norm(A_true, axis=0, keepdims=True)
    n = A_true.shape[1]
    if A_hat.shape[1] != n:
        return np.nan
    best = np.inf
    for perm in permutations(range(n)):
        Ap = A_hat[:, list(perm)]
        # optimal sign per column
        signs = np.sign(np.sum(Ap * A_true, axis=0))
        signs[signs == 0] = 1
        err = np.linalg.norm(Ap * signs - A_true) / np.linalg.norm(A_true)
        best = min(best, err)
    return best


if __name__ == "__main__":
    # Minimal smoke test on a synthetic instantaneous mixture.
    rng = np.random.default_rng(0)
    fs = 8000
    T = fs * 2
    n, m = 3, 2
    # three sparse sources
    S = np.zeros((n, T))
    for i in range(n):
        idx = rng.choice(T, size=T // 50, replace=False)
        S[i, idx] = rng.normal(size=len(idx))
    A = rng.normal(size=(m, n)); A /= np.linalg.norm(A, axis=0, keepdims=True)
    X = A @ S + 0.01 * rng.normal(size=(m, T))
    out = ssp_mia(X, fs, n=n, rng=rng)
    print("Detected SSPs :", out["ssp_count"])
    print("Estimated n   :", out["n_hat"])
    print("Matrix error  :", round(matrix_error(out["A_hat"], A), 4))

"""
sensitivity.py -- Sensitivity studies requested by Reviewer #3.

(1) gap-statistic source-count accuracy vs SNR (incl. low SNR);
(2) gap-statistic robustness to k_max and the number of reference draws B;
(3) collinearity-threshold tau plateau (E_A vs tau).

All on controlled synthetic W-DO mixtures drawn from a shared cached pool, so
rho is measured and the runs are reproducible without audio. Fully seeded.

    python sensitivity.py --trials 30
"""
from __future__ import annotations
import argparse, json
import numpy as np
import ssp_mia as S
import baselines as B
import synth_wdo as sw


def _directions(X, fs, n_needed, tau=0.99, eta=3.0):
    f, t, Xtf, hop = S.forward_stft(X, fs, 1024, 0.75)
    e = np.linalg.norm(Xtf, axis=0).ravel()
    sigma0 = np.percentile(e, 10) / max(np.sqrt(Xtf.shape[0]), 1)
    sigma_tf = S.estimate_sigma_tf(Xtf, eta, sigma0)
    mask, _ = B.select_mask(Xtf, "ssp", eta=eta, tau=tau, sigma_tf=sigma_tf)
    U, idx = B.gram_directions_fast(Xtf, mask)
    return U


def nhat_vs_snr(pool, m, n, fs, T, snrs, trials, seed):
    out = {}
    for snr in snrs:
        rng = np.random.default_rng(seed + int(snr))
        hits, tot = 0, 0
        for _ in range(trials):
            X, A, srcs, rho = sw.make_trial(m, n, T, fs, snr, rng, pool=pool)
            U = _directions(X, fs, n)
            if len(U) < 2:
                continue
            nh = S.gap_statistic(U, k_max=8, B=20, rng=rng)
            hits += int(nh == n)
            tot += 1
        out[str(snr)] = dict(acc=hits / max(tot, 1), trials=tot)
    return out


def nhat_vs_kmax_B(pool, m, n, fs, T, snr, trials, seed):
    out = {}
    for kmax in (6, 8, 12):
        for Bdraw in (10, 20, 50):
            rng = np.random.default_rng(seed + kmax * 100 + Bdraw)
            hits, tot = 0, 0
            for _ in range(trials):
                X, A, srcs, rho = sw.make_trial(m, n, T, fs, snr, rng, pool=pool)
                U = _directions(X, fs, n)
                if len(U) < 2:
                    continue
                nh = S.gap_statistic(U, k_max=kmax, B=Bdraw, rng=rng)
                hits += int(nh == n)
                tot += 1
            out[f"kmax{kmax}_B{Bdraw}"] = dict(acc=hits / max(tot, 1), trials=tot)
    return out


def ea_vs_tau(pool, m, n, fs, T, snr, trials, seed):
    out = {}
    for tau in (0.95, 0.97, 0.99, 0.995, 0.999):
        rng = np.random.default_rng(seed + int(tau * 1000))
        eas = []
        for _ in range(trials):
            X, A, srcs, rho = sw.make_trial(m, n, T, fs, snr, rng, pool=pool)
            o = B.estimate_mixing(X, fs, n, method="ssp", tau=tau, rng=rng)
            if o["A_hat"] is not None:
                eas.append(S.matrix_error(o["A_hat"], A))
        eas = np.array(eas, float)
        out[str(tau)] = dict(EA_median=float(np.median(eas)) if len(eas) else None,
                             trials=len(eas))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--density", type=float, default=0.06)
    ap.add_argument("--pool", type=int, default=12)
    ap.add_argument("--seg_sec", type=float, default=3.0)
    ap.add_argument("--fs", type=int, default=16000)
    ap.add_argument("--seed", type=int, default=20260707)
    ap.add_argument("--out", default="sensitivity_results.json")
    args = ap.parse_args()
    T = int(args.seg_sec * args.fs)
    pool = sw.cached_pool(args.pool, T, args.fs, args.seed + 999, args.density)

    m, n = 3, 5
    res = {}
    print("nhat vs SNR (3x5) ...", flush=True)
    res["nhat_vs_snr"] = nhat_vs_snr(pool, m, n, args.fs, T,
                                     [0, 5, 10, 15, 20], args.trials, args.seed)
    print(res["nhat_vs_snr"])
    print("nhat vs kmax,B (3x5, 20 dB) ...", flush=True)
    res["nhat_vs_kmax_B"] = nhat_vs_kmax_B(pool, m, n, args.fs, T, 20,
                                           args.trials, args.seed)
    print(res["nhat_vs_kmax_B"])
    print("E_A vs tau (2x3, 20 dB) ...", flush=True)
    res["ea_vs_tau"] = ea_vs_tau(pool, 2, 3, args.fs, T, 20, args.trials, args.seed)
    print(res["ea_vs_tau"])
    with open(args.out, "w") as f:
        json.dump(res, f, indent=2)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()

"""
runtime_benchmark.py -- Wall-clock runtime of SSP-MIA (Reviewer #3, point 5).

Measures the per-mixture wall-clock time of the full pipeline and of its
individual stages (STFT, SSP detection + direction estimation, spherical
k-means, source recovery) on controlled synthetic 3-second mixtures, on a
single CPU core. Reports mean +/- std over repeats and the real-time factor
(wall-clock / audio-duration). Seeded; numpy/scipy only.

    python runtime_benchmark.py --repeats 20
"""
from __future__ import annotations
import argparse, json, time
import numpy as np
import ssp_mia as S
import synth_wdo as sw


def time_pipeline(X, fs, n, rng):
    stages = {}
    t0 = time.perf_counter()
    f, t, Xtf, hop = S.forward_stft(X, fs, 1024, 0.75)
    stages["stft"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    e = np.linalg.norm(Xtf, axis=0).ravel()
    sigma0 = np.percentile(e, 10) / max(np.sqrt(Xtf.shape[0]), 1)
    sigma_tf = S.estimate_sigma_tf(Xtf, 3.0, sigma0)
    mask, _ = S.detect_ssp(Xtf, 0.99, 3.0, sigma_tf)
    U, idx = S.gram_directions(Xtf, mask)
    stages["ssp_detect"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    C, lab, _ = S.spherical_kmeans(U, n, n_restarts=10, rng=rng)
    A_hat = C.T
    stages["clustering"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    Shat = S.recover_sources(Xtf, A_hat, mask, U, idx, n, sigma_tf=sigma_tf)
    _ = S.inverse_stft(Shat, fs, 1024, 0.75)
    stages["recovery"] = time.perf_counter() - t0
    stages["total"] = sum(stages.values())
    return stages


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repeats", type=int, default=20)
    ap.add_argument("--density", type=float, default=0.06)
    ap.add_argument("--pool", type=int, default=12)
    ap.add_argument("--seg_sec", type=float, default=3.0)
    ap.add_argument("--fs", type=int, default=16000)
    ap.add_argument("--seed", type=int, default=20260707)
    ap.add_argument("--out", default="runtime_results.json")
    args = ap.parse_args()
    T = int(args.seg_sec * args.fs)
    pool = sw.cached_pool(args.pool, T, args.fs, args.seed + 999, args.density)

    res = {}
    for cfg, (m, n) in {"2x3": (2, 3), "3x5": (3, 5)}.items():
        rng = np.random.default_rng(args.seed)
        acc = {}
        for _ in range(args.repeats):
            X, A, srcs, rho = sw.make_trial(m, n, T, args.fs, 20.0, rng, pool=pool)
            st = time_pipeline(X, args.fs, n, rng)
            for k, v in st.items():
                acc.setdefault(k, []).append(v)
        res[cfg] = {k: dict(mean=float(np.mean(v)), std=float(np.std(v)))
                    for k, v in acc.items()}
        res[cfg]["realtime_factor"] = res[cfg]["total"]["mean"] / args.seg_sec
        print(f"{cfg}: total {res[cfg]['total']['mean']*1e3:.0f} ms "
              f"(RT factor {res[cfg]['realtime_factor']:.3f})")
        for k in ("stft", "ssp_detect", "clustering", "recovery"):
            print(f"    {k:11s} {res[cfg][k]['mean']*1e3:7.1f} ms")
    with open(args.out, "w") as f:
        json.dump(res, f, indent=2)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()

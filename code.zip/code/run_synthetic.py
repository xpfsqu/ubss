"""
run_synthetic.py -- Controlled synthetic W-DO Monte-Carlo evaluation.

Compares the proposed SSP gate against (i) the no-gating ablation and (ii) an
adaptive-threshold SCA baseline (Otsu on the collinearity map), on controlled
synthetic instantaneous W-DO mixtures, over the same {2x3, 2x4, 3x5}
configurations as the real-audio experiments. For every trial the W-DO
parameter rho is MEASURED on the generated sources (never assumed). Paired
Wilcoxon signed-rank tests on the per-trial matrix error E_A are reported
(Reviewer #3, paired hypothesis tests).

This reproduces the CONTROLLED-synthetic table in the revised manuscript.
Depends only on numpy/scipy. Fully seeded.

    python run_synthetic.py --trials 40 --snr 20 --density 0.03
"""
from __future__ import annotations
import argparse, json
import numpy as np
from scipy import stats

import ssp_mia as S
import baselines as B
import synth_wdo as sw

CONFIGS = {"2x3": (2, 3), "2x4": (2, 4), "3x5": (3, 5)}
METHODS = ["ssp", "nogate", "adaptive"]


def run_config(m, n, trials, snr, density, seg_sec, fs, seed, pool=None):
    rng = np.random.default_rng(seed)
    ea = {k: [] for k in METHODS}
    nsel = {k: [] for k in METHODS}
    rhos = []
    T = int(seg_sec * fs)
    if pool is None:
        pool = sw.make_pool(max(8, n + 5), T, fs, rng, density=density)
    done = 0
    for _ in range(trials):
        X, A, srcs, rho = sw.make_trial(m, n, T, fs, snr, rng,
                                        density=density, pool=pool)
        if not np.isfinite(rho):
            continue
        ok = True
        row = {}
        for meth in METHODS:
            out = B.estimate_mixing(X, fs, n, method=meth, rng=rng)
            if out["A_hat"] is None:
                ok = False
                break
            row[meth] = (S.matrix_error(out["A_hat"], A), out["n_selected"])
        if not ok:
            continue
        rhos.append(rho)
        for meth in METHODS:
            ea[meth].append(row[meth][0])
            nsel[meth].append(row[meth][1])
        done += 1
    res = {"m": m, "n": n, "trials": done,
           "rho_mean": float(np.mean(rhos)), "rho_std": float(np.std(rhos))}
    for meth in METHODS:
        v = np.array(ea[meth], float)
        res[meth] = {"EA_median": float(np.median(v)),
                     "EA_mean": float(v.mean()), "EA_std": float(v.std(ddof=1)),
                     "nsel_median": float(np.median(nsel[meth]))}
    # paired Wilcoxon signed-rank tests on E_A (ssp vs each baseline)
    res["paired"] = {}
    for base in ("nogate", "adaptive"):
        a = np.array(ea["ssp"], float)
        b = np.array(ea[base], float)
        try:
            W, p = stats.wilcoxon(a, b, alternative="less")
        except ValueError:
            W, p = float("nan"), float("nan")
        med_ratio = float(np.median(b) / max(np.median(a), 1e-12))
        res["paired"][f"ssp_vs_{base}"] = {
            "wilcoxon_W": float(W), "p_value": float(p),
            "median_improvement_x": med_ratio}
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=40)
    ap.add_argument("--snr", type=float, default=20.0)
    ap.add_argument("--density", type=float, default=0.12)
    ap.add_argument("--seg_sec", type=float, default=2.0)
    ap.add_argument("--pool", type=int, default=12,
                    help="shared synthetic source-pool size")
    ap.add_argument("--fs", type=int, default=16000)
    ap.add_argument("--seed", type=int, default=20260707)
    ap.add_argument("--out", default="synthetic_results.json")
    args = ap.parse_args()

    T = int(args.seg_sec * args.fs)
    print(f"loading/building shared synthetic source pool ({args.pool} "
          f"sources, density={args.density}) ...", flush=True)
    pool = sw.cached_pool(args.pool, T, args.fs, args.seed + 999, args.density)

    allres = {}
    for cfg, (m, n) in CONFIGS.items():
        print(f"\n=== {cfg} (m={m}, n={n})  SNR={args.snr}dB  "
              f"density={args.density}  trials={args.trials} ===")
        r = run_config(m, n, args.trials, args.snr, args.density,
                       args.seg_sec, args.fs, args.seed, pool=pool)
        allres[cfg] = r
        print(f"  measured rho = {r['rho_mean']:.3f} +/- {r['rho_std']:.3f}  "
              f"({r['trials']} valid trials)")
        for meth in METHODS:
            d = r[meth]
            print(f"  {meth:9s}: E_A median={d['EA_median']:.4f}  "
                  f"mean={d['EA_mean']:.4f}+/-{d['EA_std']:.4f}  "
                  f"bins~{d['nsel_median']:.0f}")
        for k, v in r["paired"].items():
            print(f"  {k}: median improvement {v['median_improvement_x']:.1f}x, "
                  f"Wilcoxon p={v['p_value']:.2e}")

    with open(args.out, "w") as f:
        json.dump(allres, f, indent=2)
    print(f"\nWrote {args.out}")


if __name__ == "__main__":
    main()

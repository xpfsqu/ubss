"""
bss_metrics.py — BSS_EVAL-style separation metrics.

Implements the standard decomposition of an estimated source into 
target / interference / artifact components (Vincent et al. 2006) to
produce SDR, SIR, and SAR, plus the scale-invariant SI-SDR. Also provides
a permutation-aligned wrapper that matches estimated sources to references
by maximal SIR, as described in Section 5.1 of the paper.
"""

from __future__ import annotations
import numpy as np
from itertools import permutations


def _project(s_est, sources, flen=512):
    """
    Least-squares projection of s_est onto the subspace spanned by
    delayed versions of the reference sources. Returns (s_target,
    e_interf, e_artif) for the FIRST reference being the target.
    A simplified, single-tap version is used here for speed and
    determinism; it is the standard bss_eval_sources decomposition with
    filter length 1 (i.e. gain-only projection), which is appropriate for
    instantaneous mixtures.
    """
    n = sources.shape[0]
    # gain-only projection onto each reference
    # target component: projection onto the true source (index 0 here)
    ref = sources
    G = ref @ ref.T                       # (n, n) Gram
    c = ref @ s_est                       # (n,)
    coeff = np.linalg.solve(G + 1e-12 * np.eye(n), c)
    s_proj = coeff @ ref                  # projection onto all-sources span
    return s_proj, coeff


def bss_eval_pair(s_est, s_true, sources):
    """
    Compute SDR/SIR/SAR (dB) for one estimated source s_est whose intended
    reference is s_true, given the full set of reference sources.
    """
    # target: projection onto s_true alone
    a = np.dot(s_est, s_true) / (np.dot(s_true, s_true) + 1e-12)
    s_target = a * s_true
    # projection onto the span of all sources
    s_proj, _ = _project(s_est, sources)
    e_interf = s_proj - s_target
    e_artif = s_est - s_proj

    def p(x):
        return np.sum(x ** 2) + 1e-12

    sdr = 10 * np.log10(p(s_target) / p(e_interf + e_artif))
    sir = 10 * np.log10(p(s_target) / p(e_interf))
    sar = 10 * np.log10(p(s_proj) / p(e_artif))
    return sdr, sir, sar


def si_sdr(s_est, s_true):
    """Scale-invariant SDR (dB)."""
    alpha = np.dot(s_est, s_true) / (np.dot(s_true, s_true) + 1e-12)
    target = alpha * s_true
    noise = s_est - target
    return 10 * np.log10((np.sum(target ** 2) + 1e-12) /
                         (np.sum(noise ** 2) + 1e-12))


def evaluate_permuted(S_est, S_true):
    """
    Match estimated sources to references by best mean-SIR permutation and
    return mean SDR, SIR, SAR, SI-SDR over the matched pairs.

    S_est, S_true : (n, T) arrays (already length-aligned).
    """
    n = S_true.shape[0]
    ne = S_est.shape[0]
    # align lengths
    T = min(S_est.shape[1], S_true.shape[1])
    S_est = S_est[:, :T]
    S_true = S_true[:, :T]

    # if estimator returned a different count, pad/truncate to n rows
    if ne < n:
        S_est = np.vstack([S_est, np.zeros((n - ne, T))])
    elif ne > n:
        S_est = S_est[:n]

    best = None
    best_sir = -np.inf
    for perm in permutations(range(n)):
        sirs = []
        for j, pi in enumerate(perm):
            _, sir, _ = bss_eval_pair(S_est[pi], S_true[j], S_true)
            sirs.append(sir)
        msir = np.mean(sirs)
        if msir > best_sir:
            best_sir = msir
            best = perm

    sdrs, sirs, sars, sisdrs = [], [], [], []
    for j, pi in enumerate(best):
        sdr, sir, sar = bss_eval_pair(S_est[pi], S_true[j], S_true)
        sdrs.append(sdr); sirs.append(sir); sars.append(sar)
        sisdrs.append(si_sdr(S_est[pi], S_true[j]))
    return (float(np.mean(sdrs)), float(np.mean(sirs)),
            float(np.mean(sars)), float(np.mean(sisdrs)))

"""
make_figure.py -- regenerate fig_ssp_gating.pdf (Fig. 1 of the paper).

Shows the Gram-matrix direction cloud on an orthographic projection of the
upper hemisphere of S^2 for a controlled 3x5 W-DO mixture, BEFORE gating (all
energy-floor-passing bins) and AFTER the SSP collinearity gate, with the true
mixing-matrix column directions overlaid. Illustrates why gating sharpens the
cloud. numpy/scipy/matplotlib only; seeded.
"""
from __future__ import annotations
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import ssp_mia as S
import baselines as B
import synth_wdo as sw


def ortho(U):
    """Orthographic (x,y) of unit 3-vectors on the upper hemisphere."""
    return U[:, 0], U[:, 1]


def main():
    rng = np.random.default_rng(20260707 + 999)
    pool = sw.cached_pool(12, 3 * 16000, 16000, 20260707 + 999, 0.06)
    trng = np.random.default_rng(3)
    X, A, srcs, rho = sw.make_trial(3, 5, 3 * 16000, 16000, 20.0, trng, pool=pool)

    f, t, Xtf, hop = S.forward_stft(X, 16000, 1024, 0.75)
    e = np.linalg.norm(Xtf, axis=0).ravel()
    sigma0 = np.percentile(e, 10) / np.sqrt(3)
    sigma_tf = S.estimate_sigma_tf(Xtf, 3.0, sigma0)
    m_all, _ = B.select_mask(Xtf, "nogate", sigma_tf=sigma_tf)
    m_ssp, _ = B.select_mask(Xtf, "ssp", sigma_tf=sigma_tf, tau=0.99)
    U_all, _ = B.gram_directions_fast(Xtf, m_all)
    U_ssp, _ = B.gram_directions_fast(Xtf, m_ssp)

    Acols = A / np.linalg.norm(A, axis=0, keepdims=True)
    Acols = Acols * np.sign(Acols[-1:])          # upper hemisphere

    fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.4))
    for ax, U, title in ((axes[0], U_all, f"(a) All active TF bins "
                          f"(no gating): {len(U_all)} points"),
                         (axes[1], U_ssp, f"(b) SSP-gated bins "
                          f"($\\tau=0.99$): {len(U_ssp)} points")):
        th = np.linspace(0, 2 * np.pi, 200)
        ax.plot(np.cos(th), np.sin(th), color="0.8", lw=1)
        x, y = ortho(U)
        ax.scatter(x, y, s=4, alpha=0.25, color="#2c6fbb",
                   label="direction estimates", rasterized=True)
        ax.scatter(Acols[0], Acols[1], s=120, marker="*",
                   color="#d1495b", edgecolor="k", zorder=5,
                   label="true columns of $A$")
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("$u_1$ (orthographic)")
        ax.set_ylabel("$u_2$ (orthographic)")
        ax.set_aspect("equal")
        ax.set_xlim(-1.08, 1.08)
        ax.set_ylim(-1.08, 1.08)
        ax.legend(loc="lower right", fontsize=8, framealpha=0.9)
    fig.suptitle(f"SSP gating of the direction cloud "
                 f"(controlled $3{{\\times}}5$ W-DO mixture, "
                 f"measured $\\rho={rho:.2f}$, SNR $=20$ dB)", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig("fig_ssp_gating.pdf", dpi=200)
    print("wrote fig_ssp_gating.pdf; "
          f"all={len(U_all)} ssp={len(U_ssp)} rho={rho:.3f}")


if __name__ == "__main__":
    main()

"""
adaptive_threshold.py -- Fixed vs. noise-adaptive collinearity threshold
(Reviewer #3, point 3). Compares the fixed tau=0.99 against the noise-adaptive
rule tau(sigma)=1-C*(sigma_tf/s_med)^2 (baselines.tau_sigma_rule) across a
range of SNRs, on controlled synthetic W-DO mixtures from the shared cached
pool. Reports median matrix error E_A for each rule at each SNR. Seeded.

    python adaptive_threshold.py --trials 30
"""
from __future__ import annotations
import argparse, json
import numpy as np
import ssp_mia as S
import baselines as B
import synth_wdo as sw


def run(pool, m, n, fs, T, snrs, trials, seed):
    out = {}
    for snr in snrs:
        rng = np.random.default_rng(seed + int(snr))
        fixed, adapt = [], []
        for _ in range(trials):
            X, A, srcs, rho = sw.make_trial(m, n, T, fs, snr, rng, pool=pool)
            of = B.estimate_mixing(X, fs, n, method="ssp", tau=0.99, rng=rng)
            oa = B.estimate_mixing(X, fs, n, method="tau_sigma", rng=rng)
            if of["A_hat"] is not None:
                fixed.append(S.matrix_error(of["A_hat"], A))
            if oa["A_hat"] is not None:
                adapt.append(S.matrix_error(oa["A_hat"], A))
        out[str(snr)] = dict(
            fixed_EA_median=float(np.median(fixed)) if fixed else None,
            adaptive_EA_median=float(np.median(adapt)) if adapt else None,
            fixed_n=len(fixed), adaptive_n=len(adapt))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--density", type=float, default=0.06)
    ap.add_argument("--pool", type=int, default=12)
    ap.add_argument("--seg_sec", type=float, default=3.0)
    ap.add_argument("--fs", type=int, default=16000)
    ap.add_argument("--seed", type=int, default=20260707)
    ap.add_argument("--out", default="adaptive_results.json")
    args = ap.parse_args()
    T = int(args.seg_sec * args.fs)
    pool = sw.cached_pool(args.pool, T, args.fs, args.seed + 999, args.density)
    res = {"3x5": run(pool, 3, 5, args.fs, T, [0, 5, 10, 15, 20],
                      args.trials, args.seed)}
    print(json.dumps(res, indent=2))
    with open(args.out, "w") as f:
        json.dump(res, f, indent=2)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()

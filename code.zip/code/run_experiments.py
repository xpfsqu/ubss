"""
run_experiments.py -- Real Monte-Carlo evaluation of SSP-MIA on LibriSpeech.

Loads real human speech from the LibriSpeech test-clean subset (.flac), mixes
randomly drawn distinct-speaker utterances with a random column-normalised
mixing matrix at a controlled SNR, and runs the ACTUAL SSP-MIA algorithm
(ssp_mia.py) on every trial.

For EACH trial this driver evaluates BOTH the proposed SSP gate AND the
no-gating ablation (baselines.estimate_mixing), so the two-column matrix-error
table in the paper is produced end-to-end by this script. It reports, per
configuration: median / mean+-std of the matrix error E_A for each method, the
BSS_EVAL SDR/SIR/SAR + SI-SDR of the SSP-MIA reconstruction, the gap-statistic
source-count accuracy, and a PAIRED Wilcoxon signed-rank test together with a
bootstrap confidence interval on the per-trial E_A difference (SSP vs no-gate).

NOTE ON DATA. No audio ships with this package. Point --libri_dir at a local
copy of the LibriSpeech test-clean subset (337 MB, CC BY 4.0, no registration,
https://www.openslr.org/12). The exact speaker IDs and seeds used in the paper
are listed in readme.md. For a controlled experiment that needs no audio, use
run_synthetic.py instead.

Usage:
    python run_experiments.py --libri_dir /path/to/LibriSpeech/test-clean --all
    python run_experiments.py --config 2x4_speech --snr 20 --trials 200
"""
from __future__ import annotations
import argparse, glob, os, sys, json
import numpy as np
import soundfile as sf
from scipy import stats

import ssp_mia as S
import bss_metrics as M
import baselines as B

METHODS = ["ssp", "nogate"]


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_pool(libri_dir, fs_target=16000):
    files = sorted(glob.glob(os.path.join(libri_dir, "**", "*.flac"),
                             recursive=True))
    seen = {}
    for f in files:
        base = os.path.basename(f).split("_")[-1]
        if base not in seen:
            seen[base] = f
    sigs, names = [], []
    for base, f in sorted(seen.items()):
        d, sr = sf.read(f)
        if d.ndim > 1:
            d = d.mean(axis=1)
        assert sr == fs_target, f"{base}: expected {fs_target} Hz, got {sr}"
        sigs.append(d.astype(np.float64))
        names.append(base)
    if not sigs:
        raise SystemExit(
            f"No .flac found under {libri_dir!r}. Download the LibriSpeech "
            f"test-clean subset from https://www.openslr.org/12 and pass "
            f"--libri_dir, or run run_synthetic.py for the audio-free study.")
    return sigs, names, fs_target


def make_sources(pool, n, seg_len, rng):
    P = len(pool)
    chosen = []
    order = rng.permutation(P)
    k = 0
    while len(chosen) < n:
        sig = pool[order[k % P]]
        wrap = k // P
        start_max = max(1, len(sig) - seg_len)
        start = (wrap * seg_len + rng.integers(0, start_max)) % start_max
        seg = sig[start:start + seg_len]
        if len(seg) < seg_len:
            seg = np.pad(seg, (0, seg_len - len(seg)))
        seg = seg - np.mean(seg)
        rms = np.sqrt(np.mean(seg ** 2)) + 1e-12
        chosen.append(seg / rms)
        k += 1
    return np.stack(chosen)


def sample_mixing(m, n, rng, cond_max=100.0, min_angle_deg=5.0):
    min_cos = np.cos(np.deg2rad(min_angle_deg))
    A = None
    for _ in range(1000):
        A = rng.normal(size=(m, n))
        A /= np.linalg.norm(A, axis=0, keepdims=True)
        if np.linalg.cond(A) > cond_max:
            continue
        G = np.abs(A.T @ A)
        np.fill_diagonal(G, 0.0)
        if G.max() > min_cos:
            continue
        return A
    return A


def add_noise(X, snr_db, rng):
    sp = np.mean(X ** 2)
    npow = sp / (10 ** (snr_db / 10.0))
    return X + np.sqrt(npow) * rng.normal(size=X.shape)


# ---------------------------------------------------------------------------
# One trial: run BOTH methods on the SAME mixture (paired design)
# ---------------------------------------------------------------------------
def run_trial(pool, fs, m, n, snr_db, seg_sec, rng):
    seg_len = int(seg_sec * fs)
    srcs = make_sources(pool, n, seg_len, rng)
    A = sample_mixing(m, n, rng)
    X = add_noise(A @ srcs, snr_db, rng)

    row = {}
    for meth in METHODS:
        o = B.estimate_mixing(X, fs, n, method=meth, rng=rng)
        row[f"ea_{meth}"] = (S.matrix_error(o["A_hat"], A)
                             if o["A_hat"] is not None else np.nan)

    # full SSP-MIA reconstruction (for separation metrics + n_hat)
    out = S.ssp_mia(X, fs, n=n, rng=rng)
    row["ea_sspmia"] = S.matrix_error(out["A_hat"], A)
    sdr, sir, sar, sisdr = M.evaluate_permuted(out["s_hat"], srcs)
    row.update(sdr=sdr, sir=sir, sar=sar, sisdr=sisdr,
               nhat=out["n_hat"], ssp=out["ssp_count"])
    return row


def _paired_stats(a, b, n_boot=5000, seed=0):
    """Paired Wilcoxon (a<b, one-sided) + bootstrap CI on median(b-a)."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 2:
        return dict(wilcoxon_p=float("nan"), median_diff=float("nan"),
                    ci95=[float("nan"), float("nan")], n=int(len(a)))
    try:
        _, p = stats.wilcoxon(a, b, alternative="less")
    except ValueError:
        p = float("nan")
    rng = np.random.default_rng(seed)
    d = b - a
    boot = [np.median(rng.choice(d, len(d), replace=True)) for _ in range(n_boot)]
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return dict(wilcoxon_p=float(p), median_diff=float(np.median(d)),
                ci95=[float(lo), float(hi)], n=int(len(a)))


def run_config(pool, fs, m, n, snr_db, trials, seg_sec, seed):
    rng = np.random.default_rng(seed)
    rows = []
    for t in range(trials):
        try:
            rows.append(run_trial(pool, fs, m, n, snr_db, seg_sec, rng))
        except Exception as e:
            print(f"  trial {t}: skipped ({e})", file=sys.stderr)

    def col(key):
        v = np.array([r.get(key, np.nan) for r in rows], float)
        return v[np.isfinite(v)]

    out = {"n_trials": len(rows)}
    for meth in METHODS:
        v = col(f"ea_{meth}")
        out[f"EA_{meth}"] = dict(
            median=float(np.median(v)) if len(v) else float("nan"),
            mean=float(v.mean()) if len(v) else float("nan"),
            std=float(v.std(ddof=1)) if len(v) > 1 else 0.0)
    for key in ("sir", "sdr", "sar", "sisdr"):
        v = col(key)
        out[key] = dict(mean=float(v.mean()) if len(v) else float("nan"),
                        std=float(v.std(ddof=1)) if len(v) > 1 else 0.0)
    out["nhat_acc"] = float(np.mean([r["nhat"] == n for r in rows])) if rows else 0.0
    out["paired_ssp_vs_nogate"] = _paired_stats(
        [r["ea_ssp"] for r in rows], [r["ea_nogate"] for r in rows], seed=seed)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--libri_dir", default="/mnt/user-data/uploads")
    ap.add_argument("--config", default="2x4_speech",
                    choices=["2x3_speech", "2x4_speech", "3x5_speech"])
    ap.add_argument("--snr", type=float, default=20.0)
    ap.add_argument("--trials", type=int, default=50)
    ap.add_argument("--seg_sec", type=float, default=3.0)
    ap.add_argument("--seed", type=int, default=20260512)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default="real_results.json")
    args = ap.parse_args()

    pool, names, fs = load_pool(args.libri_dir)
    print(f"Loaded {len(pool)} LibriSpeech utterances "
          f"({', '.join(names)}) at {fs} Hz", file=sys.stderr)

    cfg_map = {"2x3_speech": (2, 3), "2x4_speech": (2, 4), "3x5_speech": (3, 5)}
    configs = (["2x3_speech", "2x4_speech", "3x5_speech"]
               if args.all else [args.config])
    results = {}
    for cfg in configs:
        m, n = cfg_map[cfg]
        print(f"\n=== {cfg} (m={m},n={n}) SNR={args.snr}dB trials={args.trials} ===")
        res = run_config(pool, fs, m, n, args.snr, args.trials, args.seg_sec,
                         args.seed)
        results[cfg] = res
        print(f"  E_A  SSP-MIA   median={res['EA_ssp']['median']:.4f}  "
              f"mean={res['EA_ssp']['mean']:.4f}+/-{res['EA_ssp']['std']:.4f}")
        print(f"  E_A  no-gate   median={res['EA_nogate']['median']:.4f}  "
              f"mean={res['EA_nogate']['mean']:.4f}+/-{res['EA_nogate']['std']:.4f}")
        pr = res["paired_ssp_vs_nogate"]
        print(f"  paired (SSP<no-gate): Wilcoxon p={pr['wilcoxon_p']:.2e}, "
              f"median E_A reduction={pr['median_diff']:.4f} "
              f"(95% CI {pr['ci95'][0]:.4f}..{pr['ci95'][1]:.4f})")
        print(f"  SIR={res['sir']['mean']:.1f}+/-{res['sir']['std']:.1f} dB   "
              f"n_hat acc={res['nhat_acc']:.0%}")

    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nWrote {args.out}", file=sys.stderr)


if __name__ == "__main__":
    main()

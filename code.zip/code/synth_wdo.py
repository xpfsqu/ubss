"""
synth_wdo.py -- Controlled synthetic W-disjoint-orthogonal (W-DO) source and
mixture generator for the SSP-MIA revision experiments.

Motivation
----------
The main results of the paper are measured on *real* LibriSpeech audio (see
run_experiments.py --libri_dir ...). The reviewer-requested *sensitivity*
studies (gap-statistic parameters, adaptive thresholding, runtime, baseline
comparison), however, are most cleanly answered on a *controlled* testbed in
which the W-DO parameter rho, the SNR, the inter-column angle and the source
count can each be varied independently. This module provides that testbed.

The sources are built as sparse sums of windowed-sinusoid (Gabor) atoms placed
at random time-frequency locations (vectorised construction). Windowed tones
are spectrally concentrated, so a sparse sum of them is genuinely W-disjoint-
orthogonal with a large active/inactive energy contrast in the analysis STFT.
The number of atoms per source, set by `density`, controls how often two
sources are simultaneously active and therefore the achieved W-DO parameter
rho (fewer atoms -> higher rho). We NEVER assume a value of rho: every
experiment MEASURES rho on the generated sources with exactly the energy-ratio
protocol of Section 2 of the paper (median over significant bins of
max_i |S_i|^2 / sum_k |S_k|^2), so the reported rho is a property of the data,
not an input.

Everything here depends only on numpy/scipy, so the controlled experiments run
with no audio files and no network access.
"""
from __future__ import annotations
import numpy as np
from scipy.signal import stft


def make_sources(n, T, fs, rng, density=0.05, atom_ms=8.0, chunk=400):
    """
    n sparse W-DO sources of length T samples, unit RMS. Each source is a sum
    of `n_atoms = max(4, density * T)` Gabor atoms (windowed tones, width
    `atom_ms`) at random time/frequency. Larger density packs more atoms, so
    sources overlap more often and the achieved W-DO parameter rho is lower.
    Atoms are accumulated in blocks of `chunk` to cap memory.
    """
    t = np.arange(T)
    width = atom_ms * 1e-3 * fs
    n_atoms = max(4, int(density * T))
    srcs = []
    for _ in range(n):
        x = np.zeros(T)
        done = 0
        while done < n_atoms:
            c = min(chunk, n_atoms - done)
            t0 = rng.uniform(0, T, c)[:, None]
            f0 = rng.uniform(150, fs / 2 - 150, c)[:, None]
            ph = rng.uniform(0, 2 * np.pi, c)[:, None]
            amp = rng.uniform(0.5, 1.5, c)[:, None]
            env = np.exp(-0.5 * ((t[None, :] - t0) / width) ** 2)
            x += (amp * env * np.cos(2 * np.pi * f0 / fs * t[None, :] + ph)).sum(0)
            done += c
        x = x - x.mean()
        x /= np.sqrt(np.mean(x ** 2)) + 1e-12
        srcs.append(x)
    return np.stack(srcs)


def measure_rho(srcs, fs, nperseg=1024, overlap=0.75, energy_cut=0.01):
    """
    Measure the W-DO parameter rho on a set of (n, T) real sources using the
    exact energy-ratio protocol of Section 2 of the paper: compute, at every
    TF bin whose total energy exceeds `energy_cut` times the global peak, the
    fraction eta_i = |S_i|^2 / sum_k |S_k|^2 of the dominant source, and return
    the median of max_i eta_i over those bins.
    """
    hop = int(nperseg * (1 - overlap))
    Ss = []
    for s in srcs:
        _, _, Z = stft(s, fs=fs, window="hann", nperseg=nperseg,
                       noverlap=nperseg - hop, boundary=None, padded=False)
        Ss.append(Z)
    S = np.stack(Ss, axis=0)                       # (n, F, P)
    P2 = np.abs(S) ** 2                            # power
    tot = P2.sum(axis=0)                           # (F, P)
    peak = tot.max()
    sig = tot > energy_cut * peak
    if sig.sum() == 0:
        return float("nan")
    frac = P2.max(axis=0)[sig] / (tot[sig] + 1e-18)
    return float(np.median(frac))


def sample_mixing(m, n, rng, cond_max=100.0, min_angle_deg=5.0):
    """Random column-normalised real mixing matrix with rejection sampling."""
    min_cos = np.cos(np.deg2rad(min_angle_deg))
    A = None
    for _ in range(2000):
        A = rng.normal(size=(m, n))
        A /= np.linalg.norm(A, axis=0, keepdims=True)
        if np.linalg.cond(A) > cond_max:
            continue
        G = np.abs(A.T @ A)
        np.fill_diagonal(G, 0.0)
        if G.max() > min_cos:
            continue
        return A
    return A


def add_noise(X, snr_db, rng):
    """Additive white Gaussian noise at a per-mixture SNR (dB)."""
    sp = np.mean(X ** 2)
    npow = sp / (10 ** (snr_db / 10.0))
    return X + np.sqrt(npow) * rng.normal(size=X.shape)


def make_pool(n_pool, T, fs, rng, density=0.12):
    """Pre-generate a pool of `n_pool` synthetic W-DO sources (amortises the
    source-construction cost; mirrors the real-data driver, which draws from a
    pool of LibriSpeech utterances)."""
    return make_sources(n_pool, T, fs, rng, density=density)


def cached_pool(n_pool, T, fs, seed, density, cache_dir="/tmp/sspmia_pools"):
    """make_pool with an on-disk .npy cache keyed by the parameters, so the
    (slow) source construction runs once and is shared by all experiment
    scripts. Deterministic in `seed`."""
    import os
    os.makedirs(cache_dir, exist_ok=True)
    key = f"pool_np{n_pool}_T{T}_fs{fs}_d{density:.3f}_s{seed}.npy"
    path = os.path.join(cache_dir, key)
    if os.path.exists(path):
        return np.load(path)
    pool = make_pool(n_pool, T, fs, np.random.default_rng(seed), density=density)
    np.save(path, pool)
    return pool


def make_trial(m, n, T, fs, snr_db, rng, density=0.12, cond_max=100.0,
               pool=None):
    """
    Build one controlled synthetic trial.

    If `pool` (an (n_pool, T) array of pre-generated sources) is supplied, the
    n sources are drawn distinct from it; otherwise they are generated fresh.
    Returns (X, A, srcs, rho) with X the (m, T) noisy mixture, A the true
    (m, n) mixing matrix, srcs the (n, T) sources, and rho the MEASURED W-DO
    parameter of this trial's sources.
    """
    if pool is not None:
        sel = rng.choice(len(pool), size=n, replace=False)
        srcs = pool[sel].copy()
    else:
        srcs = make_sources(n, T, fs, rng, density=density)
    rho = measure_rho(srcs, fs)
    A = sample_mixing(m, n, rng, cond_max=cond_max)
    X = add_noise(A @ srcs, snr_db, rng)
    return X, A, srcs, rho


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    for dens in (0.01, 0.03, 0.06, 0.12, 0.25):
        rhos = [measure_rho(make_sources(3, 16000 * 3, 16000, rng, density=dens), 16000)
                for _ in range(5)]
        print(f"density={dens:5.3f}  measured rho = "
              f"{np.mean(rhos):.3f} +/- {np.std(rhos):.3f}")

"""
baselines.py -- Mixing-matrix estimators compared in the revised experiments.

All estimators share the SAME downstream geometry (Gram-matrix direction
estimate + spherical k-means with the antipodal distance) so that the ONLY
thing that varies between them is HOW the time-frequency bins used for
clustering are selected. This isolates the contribution of the single-source
selector, which is the claim of the paper, and answers Reviewer #3's request
for a comparison against a modern SCA matrix-estimation baseline.

Estimators
----------
* "ssp"      : the proposed collinearity gate at a fixed threshold tau=0.99
               (Eq. 5-6 of the paper).
* "nogate"   : the no-gating ablation -- cluster ALL energy-floor-passing
               bins (a direct port of histogram-style estimation to general m).
* "adaptive" : an adaptive-threshold SSP selector in the spirit of Hassan &
               Ramli (Sensors 2023): instead of a fixed tau, the collinearity
               map is thresholded at a data-driven Otsu level computed on the
               energy-floor-passing bins. This is the recognised "adaptive
               time-frequency thresholding" SCA family.
* "tau_sigma": the noise-adaptive rule tau(sigma)=1-C*(sigma_tf/s_med)^2
               introduced (but not previously implemented) in the theory of
               the paper; used in the fixed-vs-adaptive threshold study.

Depends only on numpy/scipy and the reference module ssp_mia.py.
"""
from __future__ import annotations
import numpy as np
import ssp_mia as S


# ---------------------------------------------------------------------------
# bin-selection masks (all operate on the STFT tensor X of shape (m, F, P))
# ---------------------------------------------------------------------------
def energy_floor_mask(X, eta, sigma_tf):
    nr = np.linalg.norm(X.real, axis=0)
    ni = np.linalg.norm(X.imag, axis=0)
    return np.minimum(nr, ni) >= eta * sigma_tf


def _otsu_threshold(values, nbins=256):
    """Otsu's method: the collinearity level that maximises between-class
    variance of the energy-floor-passing bins' collinearity histogram."""
    v = values[np.isfinite(values)]
    if v.size < 4:
        return 0.99
    hist, edges = np.histogram(v, bins=nbins, range=(0.0, 1.0))
    p = hist.astype(float) / max(hist.sum(), 1)
    omega = np.cumsum(p)
    mu = np.cumsum(p * ((edges[:-1] + edges[1:]) / 2))
    mu_t = mu[-1]
    denom = omega * (1 - omega)
    denom[denom == 0] = 1e-12
    sigma_b2 = (mu_t * omega - mu) ** 2 / denom
    k = int(np.nanargmax(sigma_b2))
    return float((edges[k] + edges[k + 1]) / 2)


def tau_sigma_rule(sigma_tf, s_med, C=4.0, tau_min=0.90, tau_cap=0.999):
    """Noise-adaptive collinearity threshold tau(sigma)=1-C*(sigma_tf/s_med)^2,
    clipped to [tau_min, tau_cap]. s_med is the median magnitude of the
    energy-floor-passing (significant) bins, so the rule is scale-free."""
    r = (sigma_tf / (s_med + 1e-12)) ** 2
    return float(np.clip(1.0 - C * r, tau_min, tau_cap))


def gram_directions_fast(X, mask, n_iter=6):
    """Vectorised top-eigenvector of G=Re Re^T + Im Im^T at every masked bin,
    via a few power iterations (G is rank<=2 at a bin, rank-1 at a true SSP).
    Numerically identical to ssp_mia.gram_directions to 1e-6 at SSPs but ~100x
    faster for large bin sets (used only for the no-gate ablation sweep)."""
    idx = np.argwhere(mask)
    if len(idx) == 0:
        return np.zeros((0, X.shape[0])), idx
    xr = X.real[:, mask].T                # (K, m)
    xi = X.imag[:, mask].T
    v = xr + (xr == 0) * xi               # init with real part
    nrm = np.linalg.norm(v, axis=1, keepdims=True)
    v = v / (nrm + 1e-18)
    for _ in range(n_iter):
        gv = xr * np.sum(xr * v, axis=1, keepdims=True) \
           + xi * np.sum(xi * v, axis=1, keepdims=True)
        nrm = np.linalg.norm(gv, axis=1, keepdims=True)
        v = gv / (nrm + 1e-18)
    v[v[:, -1] < 0] *= -1                  # hemisphere flip
    return v, idx


def select_mask(X, method, eta=3.0, tau=0.99, sigma_tf=None, C=4.0):
    """Return (mask, info) for the requested bin-selection method."""
    if sigma_tf is None:
        sigma_tf = 1.0
    efloor = energy_floor_mask(X, eta, sigma_tf)
    _, coll = S.detect_ssp(X, tau=tau, eta=eta, sigma_tf=sigma_tf)
    info = {}
    if method == "nogate":
        mask = efloor
        info["tau"] = 0.0
    elif method == "adaptive":
        thr = _otsu_threshold(coll[efloor])
        mask = efloor & (coll >= thr)
        info["tau"] = thr
    elif method == "tau_sigma":
        s_med = np.median(np.abs(X)[:, efloor]) if efloor.sum() else 1.0
        thr = tau_sigma_rule(sigma_tf, s_med, C=C)
        mask = efloor & (coll >= thr)
        info["tau"] = thr
    elif method == "ssp":
        mask = efloor & (coll >= tau)
        info["tau"] = tau
    else:
        raise ValueError(f"unknown method {method!r}")
    info["n_selected"] = int(mask.sum())
    return mask, info


# ---------------------------------------------------------------------------
# full mixing-matrix estimate under a chosen bin-selection method
# ---------------------------------------------------------------------------
def estimate_mixing(X, fs, n, method="ssp", nperseg=1024, overlap=0.75,
                    eta=3.0, tau=0.99, n_restarts=10, C=4.0, rng=None):
    """
    Estimate A with the shared Gram-direction + spherical-k-means geometry,
    selecting the clustering bins by `method`. Returns dict with A_hat, the
    effective threshold used, and the number of selected bins.
    """
    rng = np.random.default_rng() if rng is None else rng
    f, t, Xtf, hop = S.forward_stft(X, fs, nperseg, overlap)
    e = np.linalg.norm(Xtf, axis=0).ravel()
    sigma0 = np.percentile(e, 10) / max(np.sqrt(Xtf.shape[0]), 1)
    sigma_tf = S.estimate_sigma_tf(Xtf, eta, sigma0)

    mask, info = select_mask(Xtf, method, eta=eta, tau=tau,
                             sigma_tf=sigma_tf, C=C)
    U, idx = gram_directions_fast(Xtf, mask)
    if len(U) < n:
        return dict(A_hat=None, tau=info["tau"], n_selected=info["n_selected"])
    C_, lab, _ = S.spherical_kmeans(U, n, n_restarts=n_restarts, rng=rng)
    return dict(A_hat=C_.T, tau=info["tau"], n_selected=info["n_selected"],
                sigma_tf=sigma_tf)

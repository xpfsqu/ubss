 Reproduction package

Underdetermined Blind Source Separation via Time–Frequency Single-Source Point
Detection and the Minimum Intersection Angle Rule.

This package reproduces every number reported in the manuscript. It is split
into two independent evaluation paths:

1. Real-audio path (`run_experiments.py`) — the main results of Section 5,
   measured on real LibriSpeech test-clean speech. No audio ships with this
   package (see Data below); you supply the corpus.
2. Controlled-synthetic path (`run_synthetic.py`, `sensitivity.py`,
   `adaptive_threshold.py`, `runtime_benchmark.py`) — the sensitivity,
   baseline, adaptive-threshold and runtime studies added in revision. These
   use a synthetic W-disjoint-orthogonal (W-DO) generator and therefore run
   with no audio files and no network access, using only `numpy`/`scipy`.

> On every path the W-DO parameter ρ is measured on the generated/loaded
> sources with the energy-ratio protocol of Section 2; it is never assumed.

## Contents

| File | Description |
|------|-------------|
| `ssp_mia.py` | Reference implementation of Algorithm 1 (full SSP-MIA pipeline). |
| `bss_metrics.py` | BSS_EVAL SDR/SIR/SAR + SI-SDR with permutation alignment. |
| `baselines.py` | Shared matrix-estimation geometry under four bin-selection rules: `ssp` (proposed), `nogate` (ablation), `adaptive` (Otsu/Hassan–Ramli-style), `tau_sigma` (noise-adaptive τ(σ)). |
| `synth_wdo.py` | Controlled synthetic W-DO source/mixture generator (+ on-disk pool cache). |
| `run_experiments.py` | Real LibriSpeech Monte-Carlo driver. Runs both SSP-MIA and the no-gating ablation on the same mixtures and reports a paired Wilcoxon test + bootstrap CI on the per-trial E_A difference. |
| `run_synthetic.py` | Controlled-synthetic baseline comparison (ssp vs nogate vs adaptive) with paired Wilcoxon tests. |
| `sensitivity.py` | Gap-statistic accuracy vs SNR and vs (k_max, B); E_A vs τ plateau. |
| `adaptive_threshold.py` | Fixed τ=0.99 vs noise-adaptive τ(σ) across SNR. |
| `runtime_benchmark.py` | Per-stage wall-clock timing and real-time factor. |
| `requirements.txt` | Python dependencies. |

## Data

No audio is bundled. The real-audio experiments use the LibriSpeech
test-clean subset (337 MB, CC BY 4.0, no registration) from
<https://www.openslr.org/12>. The paper uses four speakers (IDs 1221, 2094,
7729, 8555); the master seed is `20260512` and the per-trial mixing/draw RNG
is derived from it. After downloading, run e.g.

```
python run_experiments.py --libri_dir /path/to/LibriSpeech/test-clean --all
```

`run_experiments.py` loads the audio, mixes randomly drawn distinct-speaker
utterances with a random column-normalised mixing matrix (condition number
capped at 100) at the requested SNR, runs the actual algorithm on every trial,
and reports median/mean±std of E_A for SSP-MIA and the no-gating ablation,
the SDR/SIR/SAR/SI-SDR of the reconstruction, the gap-statistic source-count
accuracy, and the paired significance test.

## Controlled-synthetic results (reproducible here, no audio)

`python run_synthetic.py --trials 40 --seg_sec 3.0 --snr 20 --density 0.06`
(master seed `20260707`; 40 trials/config; measured ρ reported per config):

| Config | measured ρ | E_A median (SSP) | E_A median (no-gate) | E_A median (adaptive) | SSP vs no-gate | SSP vs adaptive |
|--------|-----------|------------------|----------------------|-----------------------|----------------|-----------------|
| 2×3 | 0.92 | 0.026 | 0.042 | 0.043 | 1.6× (p=4e-6) | 1.7× (p=6e-12) |
| 2×4 | 0.83 | 0.058 | 0.266 | 0.106 | 4.6× (p=4e-11) | 1.8× (p=2e-10) |
| 3×5 | 0.76 | 0.158 | 0.326 | 0.241 | 2.1× (p=2e-12) | 1.5× (p=7e-10) |

The matrix-estimation comparison supplies the true source count to every
method so that the only thing varying is bin selection. Paired Wilcoxon
signed-rank tests (one-sided) are significant in all cases. The direction of
the effect matches the real-audio result; magnitudes are smaller on these
harder, lower-ρ synthetic mixtures.

Sensitivity (`sensitivity.py`, 30 trials): E_A is on a flat plateau across
τ∈[0.95, 0.999] (median E_A 0.019–0.035 at 2×3/20 dB); gap-statistic accuracy
is essentially insensitive to k_max∈{6,8,12} and B∈{10,20,50}, but its
absolute accuracy falls with SNR and underdeterminacy (e.g. 3×5/ρ≈0.76: 27%
at 20 dB, ~0% at ≤5 dB) — so source-number estimation is reliable only in the
favourable high-ρ, mild-underdeterminacy regime of the speech experiments.

Adaptive threshold (`adaptive_threshold.py`): the fixed τ=0.99 matches or
beats the noise-adaptive τ(σ) at SNR≥5 dB; τ(σ) only helps at 0 dB, where the
fixed threshold starves the selector.

Runtime (`runtime_benchmark.py`, single CPU core, 3-s mixtures): the
matrix-estimation stages (STFT + SSP detection + clustering) take ≈90 ms (2×3)
and ≈36 ms (3×5); the full pipeline takes ≈1.7 s (2×3) and ≈3.6 s (3×5),
dominated by the per-bin recovery loop in this unoptimised reference
(embarrassingly parallel, not yet vectorised).

## Runtime environment

Python 3.11+, NumPy ≥1.26, SciPy ≥1.13. `soundfile` is required only for the
real-audio path. `cvxpy` (SCS) and `mir_eval` are optional: the ℓ1 fall-back
defaults to a fast NumPy IRLS surrogate when CVXPY is absent, and metrics are
computed natively with an optional `mir_eval` cross-check. All randomness is
seeded from a single master seed.
